/*
 * Interface for create an auto
 */


package adapter;

public interface CreateAuto {
	public void buildAuto(String filename);
	public void printAuto(String Modelname);
	
}
