/*
 * Abstract class for build an auto
 */
package adapter;

public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto{ 
	
}